<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cjanroap_yoga' );
/** MySQL database username */
define( 'DB_USER', 'cjanroap_yoga' );
define('WP_DEBUG', false);
/** MySQL database password */
define( 'DB_PASSWORD', 'Airlines!234567890' );
/** MySQL hostname */
define( 'DB_HOST', 'localhost' );
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );
/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '.4lZQdlys/{O]|cxKBFek5)VvXQ0d<S_ a8S||sM5|Vu,c8;uH?.jQmtP/uHSc{Q' );
define( 'SECURE_AUTH_KEY',  '*w J*AsI<vRU`h}~)>MoDvuFY9Qa`dx/W$z|q(4t1`Z&tX{8g20]9jb9*LI3@f0=' );
define( 'LOGGED_IN_KEY',    '4C/ O_usZg#I]<K{5QIQRDYe*eK[K_Ntuf|QArFWaGI-v -(ykM{R+7+c* 0bc[Q' );
define( 'NONCE_KEY',        'kzVb2Q*DsFI]{,jDYS]R*g$l-U)0 SMWz2{63j^<%rB?cT40m $nKDiIo+Y73*Zp' );
define( 'AUTH_SALT',        't2{y3:%)Oo^+Tw)^|KebGnQ.`F:+n3_jkWTFgmeQ#gga%}-f~cW]{ Y/kCdZY~dR' );
define( 'SECURE_AUTH_SALT', 'X~oMz4:5ss6cy8QxT4n3zoRcRwV~lB:=:vk)~9?=H ?{Xq_v^GB]haU:D5p.%Mo_' );
define( 'LOGGED_IN_SALT',   'HdP,/>kkn[ARf#g9?Ab+k5gV|h_q_~;o9C:omR}jlH8o4w^4r>fv{J6i%nzo6i,a' );
define( 'NONCE_SALT',       'uT|MTm;o,dY$3(RoYm2d>LN{/{T~)&KV/4yU|q&^H4)-8? OW@gzv*BMWy:Qfp|2' );
/**#@-*/
/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );
define( 'FS_METHOD', 'direct' );


define('AUTOSAVE_INTERVAL', 300); // seconds
define('WP_POST_REVISIONS', false);
/* That's all, stop editing! Happy publishing. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}
define('WP_MEMORY_LIMIT', '256M');
/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
